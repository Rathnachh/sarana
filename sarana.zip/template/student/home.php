<?php require_once('../_layout/head_student.php') ;?>

        <div class="content shadow p-3 bg-white">
           <div class="cover-img">
                <h3>អន្តេវាសិកដ្ឋាននិស្សិតនៅសាកលវិទ្យាល័យ ហេង សំរិន ត្បូងឃ្មុំ</h3>
           </div>
        </div>

<?php require_once('../_layout/foot_student.php') ;?>

<script>
    $(function() {
        $('.dashboardMainNav').addClass('active');
    })
</script>

