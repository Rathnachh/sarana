<?php require_once('../_layout/head_student.php'); ?>

 <!-- <div class="content shadow p-3 bg-white">
           <div class="cover-img">
                <h3>អន្តេវាសិកដ្ឋាននិស្សិតនៅសាកលវិទ្យាល័យ ហេង សំរិន ត្បូងឃ្មុំ</h3>
           </div>
        </div> -->

<div class="d-flex justify-content-center align-items-center cover-img">
    <div class=" w-75" style="z-index: 100;opacity:0.75">
        <div class="py-5 bg-light text-center bg-info" style="border-radius:30px">
            <img src="https://th.bing.com/th/id/OIP.vHD8zypMJDmmGzaADoUoYQHaDt?rs=1&pid=ImgDetMain" class="w-50 img-fluid rounded " alt="...">
            <h4 class=" text-center dispaly-4 kh-text text-info font-weight-bolder">អន្តេវាសិកដ្ឋាននិស្សិតនៅសាកលវិទ្យាល័យ ហេង សំរិន ត្បូងឃ្មុំ សូមស្វាគមន៍</h4>
        </div>
    </div>
</div>


<?php require_once('../_layout/foot_student.php'); ?>

<script>
    $(function() {
        $('.dashboardMainNav').addClass('active');
    })
</script>