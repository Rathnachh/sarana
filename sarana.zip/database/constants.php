<?php
session_start();
define("HOST","localhost");
define("USER","root");
define("PASS","");
define("DB","db_sarana");
define("DOMAIN","http://localhost:8080/sarana");

?>