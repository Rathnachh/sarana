<?php
session_start();
define("HOST","localhost");
define("USER","root");
define("PASS","");
define("DB","db_sarana");
define("DOMAIN","http://localhost:80/sarana");
define("DOMIAN","http://localhost:80/sarana/");
?>

